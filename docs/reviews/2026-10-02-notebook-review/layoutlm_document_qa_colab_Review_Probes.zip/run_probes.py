"""Probes for the Notebook Review Framework v1 review of tutorials/layoutlm_document_qa_colab.ipynb (LDQ).

Direct execution, CPU only, Windows, CPython 3.12 conda env (torch 2.13.0+cpu, NOT the pinned 2.14.0;
transformers 4.57.6, safetensors 0.8.0, numpy 2.5.3, pillow 12.3.0). The notebook's own carried-module cells
(5, 7, 9) are exec'd from the committed .ipynb; the pinned snapshot is read (read-only) from a pre-staged local copy
whose digests verify_snapshot checks; the CORD-v2 column comes from a pre-staged cache that fetch_corpus re-digests.
No GPU, no Hub download, no pip install. Every probe is labelled with what it stands in for.

Usage: python run_probes.py <repo_worktree> <staged_weights_dir> <staged_cord_cache_dir> <out_dir>
"""
from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import time
import traceback
from pathlib import Path

REPO, WEIGHTS, CORD, OUT = (Path(a) for a in sys.argv[1:5])
NB = REPO / "tutorials" / "layoutlm_document_qa_colab.ipynb"
results: dict = {"environment": {}, "probes": {}}


def record(name, fn):
    t0 = time.perf_counter()
    try:
        value = fn()
        results["probes"][name] = {"ok": True, "seconds": round(time.perf_counter() - t0, 1), "result": value}
    except Exception as exc:  # noqa: BLE001
        results["probes"][name] = {"ok": False, "seconds": round(time.perf_counter() - t0, 1),
                                   "error": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc()[-1500:]}
    (OUT / "results.json").write_text(json.dumps(results, indent=1, default=str), encoding="utf-8")
    print(name, results["probes"][name].get("ok"), flush=True)


nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]
ns: dict = {"__name__": "__main__"}
for i in (5, 7, 9):
    exec(compile(src[i], f"<cell {i}>", "exec"), ns)

import platform  # noqa: E402

import PIL  # noqa: E402
import torch  # noqa: E402
import transformers  # noqa: E402

results["environment"] = {"python": platform.python_version(), "platform": platform.platform(),
                          "torch": torch.__version__, "transformers": transformers.__version__,
                          "pillow": PIL.__version__, "device": "cpu",
                          "note": "torch differs from the notebook pin 2.14.0; CPU only; not a Colab run"}


# P01 static: markdown/template defects and declared metadata
def p01():
    md = [(i, s) for i, s in enumerate(src) if cells[i]["cell_type"] == "markdown"]
    braces = {i: s.count("{{") for i, s in md if "{{" in s}
    return {"metadata_dimer": nb["metadata"]["dimer"],
            "markdown_cells_with_literal_double_braces": braces,
            "example": re.search(r"`\{\{id[^`]*`", src[0]).group(0) if "{{id" in src[0] else None,
            "install_cell_has_restart_guard": "Restart the runtime" in src[3],
            "byod_branch_imports_google_colab_unconditionally": "from google.colab import files" in src[13],
            "byod_location_field_present": bool(re.search(r"BYOD_(PATH|LOCATION)", src[13])),
            "rerun_cells_reload_base_before_adapt": "from_pretrained" in src[19] or "from_pretrained" in src[17],
            "learner_prediction_prompts": sum(s.lower().count("predict") for _i, s in md),
            "troubleshooting_heading": any("troubleshoot" in s.lower() for _i, s in md)}


record("P01_static", p01)


# P02 default data path: cell 13's sample branch against the digest-checked cache
def p02():
    corpus_rows = ns["fetch_corpus"](cache_dir=str(CORD))
    splits = ns["build_sample_dataset"](ns["read_corpus"](corpus_rows), seed=42)
    manifests = {k: ns["validate_dataset"](v) for k, v in splits.items()}
    disjoint = ns["check_split_disjoint"](splits)
    ns["splits"] = splits
    pages = {k: len({r["page_id"] for r in v}) for k, v in splits.items()}
    return {"raw_rows": {k: len(v) for k, v in corpus_rows.items()}, "splits": disjoint, "pages": pages,
            "digests": {k: m["digest"][:16] for k, m in manifests.items()}}


record("P02_default_dataset", p02)


# P03 frozen model on CPU: invoice inference contract (cell 15 body) + frozen test-score on a subset
def p03():
    pipe = ns["LayoutLMDocumentQAPipeline"].from_pretrained(weights_dir=WEIGHTS, device="cpu")
    ns["pipe"] = pipe
    g = dict(ns)
    body = src[15]
    # run the synthetic-form part of cell 15 only (fit check on all splits is run too)
    g["hashlib"] = __import__("hashlib")
    g["json"] = json
    g["os"] = os
    os.makedirs("outputs", exist_ok=True)
    exec(compile(body, "<cell 15>", "exec"), g)
    ns.update({k: g[k] for k in ("train_records", "val_records", "test_records", "words", "boxes", "image",
                                 "questions", "golds")})
    frozen = pipe.evaluate(g["test_records"][:60])
    return {"fit": {k: v["n_fitting"] for k, v in g["fit"].items()},
            "invoice_answers": [r["answer"] for r in g["results"]], "checks": g["checks"],
            "frozen_invoice_verdict": g["frozen_form"]["verdict"],
            "frozen_test_first60": {"anls": round(frozen["anls"], 3), "exact_match": round(frozen["exact_match"], 3)}}


record("P03_frozen_cpu", p03)


# P04 active learning: Run-all adapt, then the documented experiment "set TRAINABLE_ENCODER_LAYERS = 2" re-run
# of cell 19 -> 21 -> 23. Stand-in: 48 train / 24 val records, 1 epoch each (time cap), real weights, CPU.
def p04():
    pipe = ns["pipe"]
    tr, va, te = ns["train_records"][:48], ns["val_records"][:24], ns["test_records"]
    model = pipe._model
    base = {k: v.detach().clone() for k, v in model.state_dict().items()
            if k.startswith("layoutlm.encoder.layer.8.") or k.startswith("layoutlm.encoder.layer.9.")}
    frozen_val = pipe.evaluate(va)["anls"]
    # Stand-in for the default 6-epoch Run all: one epoch, no validation split, so the trained weights are kept
    # (with 1 epoch on 48 records validation selection can legitimately keep epoch 0 and change nothing).
    first = pipe.adapt(tr, None, epochs=1, lr=3e-5, batch_size=16, trainable_encoder_layers=4)
    after_first_val = pipe.evaluate(va)["anls"]
    second = pipe.adapt(tr, va, epochs=1, lr=3e-5, batch_size=16, trainable_encoder_layers=2)
    epoch0 = second["history"][0]
    sd = model.state_dict()
    drift_in_memory = max(float((sd[k] - base[k]).abs().max()) for k in base)
    tmp = Path(tempfile.mkdtemp(prefix="ldq_art_"))
    pipe.save_artifact(tmp / "adapter")
    man = json.loads((tmp / "adapter" / "manifest.json").read_text(encoding="utf-8"))
    reloaded = ns["LayoutLMDocumentQAPipeline"].from_artifact(tmp / "adapter", weights_dir=WEIGHTS, device="cpu")
    rsd = reloaded._model.state_dict()
    drift_reloaded = max(float((rsd[k] - base[k]).abs().max()) for k in base)
    # logit-level difference on 8 test records (the notebook compares answer strings only)
    before = [pipe.answer(r["question"], words=r["words"], boxes=r["boxes"], image_size=r["image_size"]) for r in te[:40]]
    after = [reloaded.answer(r["question"], words=r["words"], boxes=r["boxes"], image_size=r["image_size"]) for r in te[:40]]
    same8 = sum(a["answer"] == b["answer"] for a, b in zip(before[:8], after[:8]))
    same40 = sum(a["answer"] == b["answer"] for a, b in zip(before, after))
    max_score_delta = max(abs(a["score"] - b["score"]) for a, b in zip(before, after))
    return {"frozen_val_anls": round(frozen_val, 4), "first_adapt": {"n_trainable": first["n_trainable"], "best_epoch": first["best_epoch"], "selection": first["selection"]},
            "val_anls_after_first_adapt": round(after_first_val, 4),
            "second_adapt_epoch0": {"note": epoch0.get("note"), "val_anls": round(epoch0["val"]["anls"], 4)},
            "second_adapt_n_trainable": second["n_trainable"],
            "artifact_tensors": len(man["tensors"]),
            "layers_8_9_max_abs_change_in_memory": drift_in_memory,
            "layers_8_9_max_abs_change_in_reloaded": drift_reloaded,
            "reload_identical_answers_first8": same8, "reload_identical_answers_first40": same40,
            "reload_max_score_delta_40": max_score_delta}


if os.environ.get("LDQ_SKIP_ADAPT") != "1":
    record("P04_rerun_stacking", p04)


# P05 BYOD contract: synthetic records that satisfy the stated contract (8..20,000 records) -> cell 13 BYOD body
def _rec(i, page):
    words = ["TOTAL", f"{1000 + i}", "CASH", "5000"]
    boxes = [[10, 10 + 20 * j, 60, 25 + 20 * j] for j in range(4)]
    return {"id": f"r{i}", "page_id": page, "question": "What is the total amount?", "words": words,
            "boxes": boxes, "image_size": [200, 200], "answer_start": 1, "answer_end": 1}


def p05():
    out = {}
    for n, per_page in ((8, 1), (20, 1), (40, 1), (49, 1), (50, 1), (60, 5), (100, 5)):
        recs = [_rec(i, f"p{i // per_page}") for i in range(n)]
        try:
            sp = ns["split_dataset"](recs, seed=42)
            sizes = {k: len(v) for k, v in sp.items()}
            try:
                for name, part in sp.items():
                    ns["validate_dataset"](part)
                out[f"{n}rec_{per_page}perpage"] = {"split": sizes, "cell13": "accepted"}
            except ValueError as exc:
                out[f"{n}rec_{per_page}perpage"] = {"split": sizes, "cell13": f"ValueError: {exc}"}
        except ValueError as exc:
            out[f"{n}rec_{per_page}perpage"] = {"split": None, "cell13": f"ValueError at split: {exc}"}
    return out


record("P05_byod_minimum", p05)


# P06 BYOD invalid inputs: malformed JSONL line, wrong extension, missing key
def p06():
    out = {}
    tmp = Path(tempfile.mkdtemp(prefix="ldq_byod_"))
    good = json.dumps(_rec(0, "p0"))
    (tmp / "bad.jsonl").write_text(good + "\n" + good + "\n{not json\n", encoding="utf-8")
    (tmp / "data.csv").write_text("a,b\n", encoding="utf-8")
    missing = [{k: v for k, v in _rec(i, f"p{i}").items() if k != "answer_end"} for i in range(60)]
    (tmp / "missing.json").write_text(json.dumps(missing), encoding="utf-8")
    for name in ("bad.jsonl", "data.csv", "missing.json"):
        try:
            recs = ns["load_byod_dataset"](tmp / name)
            ns["split_dataset"](recs, seed=42)
            out[name] = "accepted"
        except Exception as exc:  # noqa: BLE001
            out[name] = f"{type(exc).__name__}: {exc}"
    try:
        import google.colab  # noqa: F401
        out["google_colab_import"] = "available"
    except ModuleNotFoundError as exc:
        out["google_colab_import"] = f"ModuleNotFoundError: {exc} (cell 13 BYOD branch on non-Colab Jupyter)"
    return out


record("P06_byod_invalid", p06)

print(json.dumps({k: v.get("ok") for k, v in results["probes"].items()}))
