"""Review probes for tutorials/DIMER_Document_QA_LayoutLM_vs_Pix2Struct_Workshop.ipynb (DQA-*).

Usage:
    python run_probes.py <notebook.ipynb> <results.json> [--quick]

Evidence basis (label every result accordingly):
- Direct execution, CPU only (CUDA hidden), Windows, the reviewer's anaconda Python.
- LayoutLM is the REAL pinned model (impira/layoutlm-document-qa@beed3c4d, digest-verified by the notebook's own
  staging cell) read from a local snapshot (env DQA_LM_WEIGHTS, hard-linked, never written).
- CORD-v2: the REAL `ground_truth` column of the two pinned shards (env DQA_CORD_DIR, the repository's
  `weights/cord-v2/*.ground_truth.json` cache). Page PIXELS are NOT available: each page image is a blank white
  stand-in of the annotated size. LayoutLM never reads pixels, so its answers are real; anything drawn on a page
  is not.
- Pix2Struct is a deterministic STAND-IN (no 1.13 GB checkpoint, no pixels). Its answers and metrics are not
  evidence about Pix2Struct.
- The install cell is not executed (it would pip-install pins); only its import/runtime tail runs. The CORD
  download cell is replaced by the local cache. Everything else runs as written, top to bottom.

Each probe reports status "open" (the finding's condition is present) or "clear".
"""
from __future__ import annotations

import contextlib
import hashlib
import inspect
import io
import json
import os
import shutil
import sys
import traceback
import types
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
LM_WEIGHTS = Path(os.environ.get("DQA_LM_WEIGHTS", HERE / "lmweights"))
CORD_DIR = Path(os.environ.get(
    "DQA_CORD_DIR", r"C:\Users\Kurt Valcorza\Projects\layoutlm-document-qa-pipeline\weights\cord-v2"))
HOSTED = {  # docs/release-verification.md, 2026-09-26 Colab T4 run of the reviewed code cells
    "test_qa_digest": "b2c58a975862d8d1dee0c57ab7945c2f8edb1d3fc0bccf95d27d126fb9cf2db5",
    "last_number_anls": 0.4055312954876274, "keyword_anls": 0.6352672073196091, "layoutlm_anls": 0.8427949914913696,
}
TEMPLATE_FIELDS = ["total.total_price", "sub_total.subtotal_price", "sub_total.tax_price", "sub_total.service_price",
                   "sub_total.discount_price", "total.cashprice", "total.changeprice", "total.creditcardprice",
                   "total.menuqty_cnt", "menu.nm"]

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")


# ----------------------------------------------------------------------------------------------- notebook access
def load_cells(path):
    nb = json.loads(Path(path).read_text(encoding="utf-8"))
    return nb, [(c.get("id"), c["cell_type"], "".join(c["source"])) for c in nb["cells"]]


def set_params(src, **values):
    """Replace `NAME = ...  # @param` lines (exactly once each)."""
    lines = src.split("\n")
    for name, value in values.items():
        hits = [i for i, line in enumerate(lines) if line.startswith(f"{name} = ")]
        if len(hits) != 1:
            raise KeyError(f"{name}: {len(hits)} assignment lines")
        tail = lines[hits[0]].split("#", 1)
        lines[hits[0]] = f"{name} = {value!r}" + (f"  #{tail[1]}" if len(tail) == 2 else "")
    return "\n".join(lines)


# ----------------------------------------------------------------------------------------------- stand-ins
class DisplayLog:
    def __init__(self):
        self.calls = []
        self.cell = None

    def display(self, *objs, **_):
        for o in objs:
            self.calls.append((self.cell, type(o).__name__))


DISPLAY = DisplayLog()


def install_fake_ipython():
    disp = types.ModuleType("IPython.display")
    disp.display = DISPLAY.display

    class _Wrap:
        def __init__(self, *a, **k):
            self.args = a

    disp.Image = disp.Markdown = disp.HTML = disp.FileLink = _Wrap
    ip = types.ModuleType("IPython")
    ip.display = disp
    sys.modules["IPython"] = ip
    sys.modules["IPython.display"] = disp


class _Batch(dict):
    def to(self, *_a, **_k):
        return self


class StandInPix:
    """Deterministic Pix2Struct stand-in: answers 'standin <len(question)>'; never sees pixels or OCR."""
    loads = 0

    class Processor:
        def __init__(self):
            self.last_q = ""
            outer = self

            class IP:
                is_vqa = True

                def __call__(self_inner, image, header_text, return_tensors, font_bytes):
                    import torch
                    outer.last_q = header_text
                    return _Batch(flattened_patches=torch.zeros(1, 4, 8), attention_mask=torch.ones(1, 4))

            class Tok:
                def batch_decode(self_inner, generated, skip_special_tokens=True):
                    return [f"standin {len(outer.last_q)}"]

            self.image_processor = IP()
            self.tokenizer = Tok()

        @classmethod
        def from_pretrained(cls, *_a, **_k):
            StandInPix.loads += 1
            return cls()

    class Model:
        @classmethod
        def from_pretrained(cls, *_a, **_k):
            StandInPix.loads += 1
            return cls()

        def to(self, *_a, **_k):
            return self

        def eval(self):
            return self

        def parameters(self):
            import torch
            return iter([torch.zeros(10)])

        def generate(self, **kw):
            import torch
            return torch.zeros(1, 3, dtype=torch.long)


class CountingLoader:
    """Wraps a transformers class so BYOD probes can tell whether a model load happened before a refusal."""
    def __init__(self, real, counter, key):
        self.real, self.counter, self.key = real, counter, key

    def from_pretrained(self, *a, **k):
        self.counter[self.key] = self.counter.get(self.key, 0) + 1
        return self.real.from_pretrained(*a, **k)


class FakePQ:
    """pyarrow.parquet stand-in: the REAL ground_truth column; a blank page of the annotated size as 'image'."""
    @staticmethod
    def read_table(path, columns=None):
        from PIL import Image
        rows = json.loads(Path(path).read_text(encoding="utf-8"))

        class T:
            def to_pylist(self_inner):
                out = []
                for gt in rows:
                    size = json.loads(gt)["meta"]["image_size"]
                    out.append({"image": Image.new("RGB", (int(size["width"]), int(size["height"])), "white"),
                                "ground_truth": gt})
                return out
        return T()


# ----------------------------------------------------------------------------------------------- patched execution
def patched_source(cid, src):
    if cid == "7984f79d":  # install cell: never pip-install; run only the import/runtime tail
        return ("import sys\nimport importlib.metadata as importlib_metadata\nNUMPY_PRELOADED = None\n"
                + src[src.index("\nimport numpy as np"):])
    if cid == "f1c86bc7":  # model staging: LayoutLM verified for real; Pix2Struct not staged (stand-in)
        old = "pix_snapshot=stage_and_verify_model(PIX2STRUCT_DIR,PIX2STRUCT_MANIFEST)"
        assert src.count(old) == 1
        return src.replace(old, "pix_snapshot={'model_id':PIX2STRUCT_MANIFEST['modelId'],'stand_in':True}")
    if cid == "84cde8b7":  # CORD download: the local digest-pinned ground_truth cache instead of the parquet shards
        return (f"CORD_REPO='naver-clova-ix/cord-v2'\nCORD_REVISION='7f0115a4b758a71d6473b8d085751692da2fef98'\n"
                f"CORD_LICENSE='CC BY 4.0'\n"
                f"CORD_FILES={{'test':{{'rows':100}},'validation':{{'rows':100}}}}\n"
                f"cord_paths={{'test':Path(r'{CORD_DIR / 'test.ground_truth.json'}'),"
                f"'validation':Path(r'{CORD_DIR / 'validation.ground_truth.json'}')}}\n")
    if "from transformers import Pix2StructForConditionalGeneration, Pix2StructProcessor" in src:
        return src.replace("from transformers import Pix2StructForConditionalGeneration, Pix2StructProcessor", "")
    return src


def make_namespace():
    install_fake_ipython()
    ns = {"__name__": "__main__"}
    return ns


def run_cell(ns, cid, src, log):
    DISPLAY.cell = cid
    buf = io.StringIO()
    err = None
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(src, f"<cell {cid}>", "exec"), ns)
    except BaseException as e:  # noqa: BLE001
        err = f"{type(e).__name__}: {e}"
    log.append({"cell": cid, "error": err, "stdout": buf.getvalue()})
    return err


def run_all(nb_path, workdir, params=None):
    """Run every code cell top to bottom (patched infrastructure); return (ns, log)."""
    _, cells = load_cells(nb_path)
    workdir = Path(workdir)
    if workdir.exists():
        shutil.rmtree(workdir)
    (workdir / "weights" / "layoutlm-document-qa").mkdir(parents=True)
    for f in LM_WEIGHTS.iterdir():
        os.link(f, workdir / "weights" / "layoutlm-document-qa" / f.name)
    os.chdir(workdir)
    ns = make_namespace()
    log = []
    for cid, kind, src in cells:
        if kind != "code":
            continue
        src = patched_source(cid, src)
        if params and "# @param" in src and "USE_BYOD" in src:
            src = set_params(src, **params)
        if cid == "050156d2":
            ns["pq"] = FakePQ
        if "Pix2StructProcessor" in src:
            ns["Pix2StructProcessor"] = StandInPix.Processor
            ns["Pix2StructForConditionalGeneration"] = StandInPix.Model
        err = run_cell(ns, cid, src, log)
        if err:
            log[-1]["traceback_hint"] = "stopped"
            break
    return ns, log, cells


# ----------------------------------------------------------------------------------------------- BYOD fixtures
def write_byod(root, records, pages, as_zip=False):
    from PIL import Image
    root = Path(root)
    if root.exists():
        shutil.rmtree(root)
    (root / "pages").mkdir(parents=True)
    for name, (w, h) in pages.items():
        Image.new("RGB", (w, h), "white").save(root / "pages" / name)
    (root / "records.jsonl").write_text("\n".join(json.dumps(r) for r in records) + "\n", encoding="utf-8")
    if as_zip:
        zpath = root.with_suffix(".zip")
        with zipfile.ZipFile(zpath, "w") as z:
            for p in root.rglob("*"):
                if p.is_file():
                    z.write(p, p.relative_to(root).as_posix())
        return zpath
    return root


def receipt_record(rid, page, q="What is the total amount?", answers=("12.50",)):
    words = ["Coffee", "3.00", "Cake", "9.50", "TOTAL", "12.50"]
    boxes = [[20, 40, 120, 60], [300, 40, 360, 60], [20, 80, 100, 100], [300, 80, 360, 100],
             [20, 140, 110, 160], [300, 140, 370, 160]]
    r = {"id": rid, "page_id": page.split(".")[0], "file": page, "question": q, "words": words, "boxes": boxes}
    if answers is not None:
        r["answers"] = list(answers)
    return r


def byod_cell_id(cells):
    return next(cid for cid, kind, src in cells if kind == "code" and "if USE_BYOD:" in src)


def run_byod(ns, cells, path, counter):
    cid = byod_cell_id(cells)
    src = dict((c, s) for c, _, s in cells)[cid]
    ns["USE_BYOD"] = True
    ns["BYOD_PATH"] = str(path)
    for name in ("LayoutLMForQuestionAnswering",):
        real = ns[name].real if isinstance(ns[name], CountingLoader) else ns[name]
        ns[name] = CountingLoader(real, counter, "layoutlm")
    ns["Pix2StructProcessor"] = CountingLoader(StandInPix.Processor, counter, "pix2struct")
    ns["Pix2StructForConditionalGeneration"] = StandInPix.Model
    log = []
    shutil.rmtree(Path(ns["OUTPUT_DIR"]) / "byod", ignore_errors=True)
    before = set(Path(ns["OUTPUT_DIR"]).rglob("*")) if Path(ns["OUTPUT_DIR"]).exists() else set()
    err = run_cell(ns, cid, patched_source(cid, src), log)
    after = set(Path(ns["OUTPUT_DIR"]).rglob("*"))
    return err, log[-1]["stdout"], sorted(str(p) for p in after - before if p.is_file())


# ----------------------------------------------------------------------------------------------- probes
def main():
    nb_path = Path(sys.argv[1]).resolve()
    out_path = Path(sys.argv[2]).resolve()
    work = HERE / "_run"
    nb, cells = load_cells(nb_path)
    md = {cid: src for cid, kind, src in cells if kind == "markdown"}
    code = {cid: src for cid, kind, src in cells if kind == "code"}
    results = {"notebook": str(nb_path),
               "notebook_sha256": hashlib.sha256(nb_path.read_bytes()).hexdigest(),
               "evidence_basis": __doc__.split("Evidence basis", 1)[1].split("Each probe", 1)[0].strip(),
               "probes": []}

    def probe(pid, finding, status, **evidence):
        results["probes"].append({"id": pid, "finding": finding, "status": status, **evidence})
        print(f"{pid} {finding}: {status}", flush=True)

    # ---- P01 default journey (real LayoutLM on CPU, stand-in Pix2Struct, real CORD annotations)
    ns, log, _ = run_all(nb_path, work / "default")
    errors = [x for x in log if x["error"]]
    m = ns.get("system_metrics", {})
    default = {
        "cells_run": len(log), "errors": [(x["cell"], x["error"]) for x in errors],
        "qa_counts": ns.get("qa_counts"), "test_qa_digest": ns.get("qa_digest"),
        "digest_matches_hosted": ns.get("qa_digest") == HOSTED["test_qa_digest"],
        "last_number_anls": m.get("Last-number baseline", {}).get("anls"),
        "keyword_anls": m.get("Keyword lookup", {}).get("anls"),
        "layoutlm_cpu_anls": m.get("LayoutLM", {}).get("anls"),
        "layoutlm_cpu_exact": m.get("LayoutLM", {}).get("exact_match"),
        "hosted": HOSTED,
        "no_layout_rows": len(ns.get("layout_no_layout_rows", [])),
    }
    default["baselines_match_hosted"] = (
        default["last_number_anls"] == HOSTED["last_number_anls"] and default["keyword_anls"] == HOSTED["keyword_anls"])
    default["layoutlm_within_0.01_of_hosted"] = (
        default["layoutlm_cpu_anls"] is not None and abs(default["layoutlm_cpu_anls"] - HOSTED["layoutlm_anls"]) < 0.01)
    exp = ns.get("experiment_records", [])
    default["experiment_subset"] = {"records": len(exp), "pages": len({r["page_id"] for r in exp}),
                                    "fields": sorted({r["field"] for r in exp})}
    default["unanswerable_pages"] = list(ns.get("probe_pages", []))
    probe("P01", "default journey (CPU, real LayoutLM, stand-in Pix2Struct)",
          "pass" if not errors and default["digest_matches_hosted"] else "fail", **default)
    stdout = {x["cell"]: x["stdout"] for x in log}

    # ---- P02 DQA-M4: the Try-it activity can be carried out after Run all and answers its own question
    order = [cid for cid, _, _ in cells]
    tri = next(i for i, (cid, kind, src) in enumerate(cells) if kind == "markdown" and src.lstrip().startswith("## Try it yourself"))
    nxt = cells[tri + 1] if tri + 1 < len(cells) else None
    target = nxt[0] if nxt and nxt[1] == "code" else "aada1835"
    src = code[target]
    if "RUN_LAYOUT_ACTIVITY" in src:
        src = set_params(src, RUN_LAYOUT_ACTIVITY=True)
    alog = []
    aerr = run_cell(ns, target, patched_source(target, src), alog)
    activity_out = alog[-1]["stdout"]
    named_fields = [f for f in TEMPLATE_FIELDS if f in activity_out]
    canonical_fieldwise = [f for f in TEMPLATE_FIELDS if f in stdout.get("aada1835", "")]
    changeable = any(("@param" in code[target]) and k in code[target] for k in ("ACTIVITY", "LAYOUT_CHANGE"))
    probe("P02", "DQA-M4",
          "open" if (aerr or not named_fields or not canonical_fieldwise or not changeable) else "clear",
          rerun_cell=target, rerun_error=aerr, fields_named_in_rerun=named_fields,
          fields_named_in_canonical_layout_experiment=canonical_fieldwise, learner_change_control=changeable,
          try_it_position=f"cell {tri} of {len(cells)} (after cell {order.index('8ad583a7')}, the terminal summary)")

    # ---- P03 DQA-m1: controls
    cfg_id = next(cid for cid, kind, s in cells if kind == "code" and "USE_BYOD = " in s)
    accepted = {}
    for value in (0, -3):
        lg = []
        e = run_cell(dict(ns), cfg_id, set_params(code[cfg_id], ROBUSTNESS_MAX_RECORDS=value), lg)
        accepted[value] = e is None
    default_val = inspect.signature(ns["pix_answer"]).parameters["max_new_tokens"].default
    stale = isinstance(default_val, int)
    probe("P03", "DQA-m1", "open" if (any(accepted.values()) or stale) else "clear",
          robustness_max_records_accepted=accepted,
          slice_for_minus_3=len(sorted(ns["test_records"], key=lambda r: r["id"])[:-3]),
          pix_answer_max_new_tokens_default=repr(default_val), default_frozen_at_definition=stale)

    # ---- P04 DQA-M1 / P05 DQA-M2: BYOD
    byod_root = work / "byod"
    page = {"p1.png": (420, 600), "p2.png": (420, 600)}
    base = [receipt_record("q1", "p1.png"), receipt_record("q2", "p2.png", q="What is the price of the cake?",
                                                          answers=("9.50",))]
    cases = {
        "missing_page_file": ([receipt_record("q1", "p1.png"), receipt_record("q9", "absent.png")], page, "q9"),
        "malformed_box": ([base[0], {**base[1], "boxes": [[1, 2, 3]] + base[1]["boxes"][1:]}], page, "q2"),
        "empty_question": ([base[0], {**base[1], "question": "   "}], page, "q2"),
        "image_side_over_4096": ([base[0], {**base[1], "file": "wide.png"}], {**page, "wide.png": (5000, 600)}, "q2"),
        "duplicate_id": ([base[0], {**base[1], "id": "q1"}], page, "q1"),
        "answers_not_a_list": ([base[0], {**base[1], "answers": "9.50"}], page, "q2"),
        "mixed_labelled_unlabelled": ([base[0], receipt_record("q2", "p2.png", answers=None)], page, "q2"),
        "empty_ocr_word": ([base[0], {**base[1], "words": [""] + base[1]["words"][1:]}], page, "q2"),
        "over_100_pages": ([receipt_record(f"q{i}", f"p{i}.png") for i in range(101)],
                           {f"p{i}.png": (64, 64) for i in range(101)}, None),
    }
    byod_cases = {}
    for name, (recs, pages, rid) in cases.items():
        if name == "over_100_pages":  # boxes must fit the 64x64 pages
            recs = [{**r, "boxes": [[1, 1, 10, 10]] * len(r["words"])} for r in recs]
        path = write_byod(byod_root / name, recs, pages)
        counter = {}
        err, out, new_files = run_byod(ns, cells, path, counter)
        loads = sum(counter.values())
        refused_early = err is not None and loads == 0
        names_record = bool(err) and (rid is None or rid in err)
        byod_cases[name] = {"error": err, "model_loads_before_refusal": loads, "refused_before_model_load": refused_early,
                            "message_names_record": names_record}
    zcase = write_byod(byod_root / "as_zip", base, page, as_zip=True)
    err, out, _ = run_byod(ns, cells, zcase, {})
    byod_cases["documented_zip_input"] = {"error": err, "accepted": err is None}
    slip = byod_root / "slip.zip"
    with zipfile.ZipFile(slip, "w") as z:
        z.writestr("../escape.txt", "x")
        z.writestr("records.jsonl", json.dumps(base[0]) + "\n")
    err, out, _ = run_byod(ns, cells, slip, {})
    byod_cases["zip_member_outside_root"] = {"error": err, "refused": err is not None,
                                             "escaped_file_written": (byod_root.parent / "escape.txt").exists()}
    byod_md = next(src for cid, kind, src in cells if kind == "markdown" and src.lstrip().startswith("## 30."))
    limits_stated = {k: (k in byod_md) for k in ("500", "100", "2000", "4096", "256")}
    locality = any(p in byod_md.lower() for p in ("does not leave", "stays in", "not sent", "never sent",
                                                  "not transmitted", "never leave"))
    bad = [n for n, c in byod_cases.items()
           if n not in ("documented_zip_input", "zip_member_outside_root")
           and not (c["refused_before_model_load"] and c["message_names_record"])]
    zip_bad = (not byod_cases["documented_zip_input"]["accepted"]) or (not byod_cases["zip_member_outside_root"]["refused"])
    probe("P04", "DQA-M1", "open" if (bad or zip_bad or not all(limits_stated.values()) or not locality) else "clear",
          cases=byod_cases, failing_cases=bad, limits_stated_in_markdown=limits_stated, data_locality_stated=locality)

    valid = write_byod(byod_root / "valid", base, page)
    err, out, new_files = run_byod(ns, cells, valid, {})
    shows_answers = all(r["id"] in out for r in base) and "standin" in out
    exported = [f for f in new_files if "byod" in f.lower()]
    unl = write_byod(byod_root / "unlabelled", [receipt_record("u1", "p1.png", answers=None)], {"p1.png": (420, 600)})
    err2, out2, new2 = run_byod(ns, cells, unl, {})
    probe("P05", "DQA-M2", "open" if (err or not shows_answers or not exported or err2 or "not-measurable" not in out2)
          else "clear", labelled_error=err, labelled_stdout=out[-1500:], per_record_answers_shown=shows_answers,
          byod_files_written=exported, unlabelled_error=err2, unlabelled_stdout=out2[-600:],
          unlabelled_files_written=[f for f in new2 if "byod" in f.lower()])

    # ---- P06 DQA-M3: pages, answer locations and individual answers visible in the notebook
    images_shown = [c for c in DISPLAY.calls if c[1] in ("Image", "PngImageFile", "JpegImageFile")]
    first_eval = order.index("de054504")
    before_eval = [c for c in images_shown if c[0] in order and order.index(c[0]) < first_eval]
    cats = sorted({e.get("agreement_category", e.get("category", "")) for e in ns.get("selected_examples", [])})
    not_in_ocr_listed = any("not_in_ocr" in c for c in cats)
    probe("P06", "DQA-M3",
          "open" if (len(images_shown) < 4 or not before_eval or not not_in_ocr_listed) else "clear",
          images_displayed=len(images_shown), images_displayed_before_first_model_result=len(before_eval),
          example_categories=cats, panel_cell_stdout=stdout.get("52ae9160", "")[-600:])

    # ---- P07 DQA-m2: rejection probes recorded in input_manifest.json were actually executed
    manifest = json.loads((Path(ns["OUTPUT_DIR"]) / "input_manifest.json").read_text(encoding="utf-8"))
    rp = manifest.get("rejection_probes", [])
    executed = bool(rp) and all(isinstance(x, dict) and x.get("refused") is True and x.get("message") for x in rp)
    probe("P07", "DQA-m2", "clear" if executed and len(rp) >= 6 else "open", rejection_probes=rp)

    # ---- P08 DQA-m3: runtime orientation
    first_md = "\n".join(src for cid, kind, src in cells[:7] if kind == "markdown")
    states_size = "GB" in first_md
    states_time = any(t in first_md for t in (" s ", "seconds", "minutes", " min"))
    cpu_warning = "no gpu" in stdout.get("7984f79d", "").lower()
    probe("P08", "DQA-m3", "clear" if (states_size and states_time and cpu_warning) else "open",
          download_size_stated_before_first_code=states_size, measured_time_stated=states_time,
          cpu_run_warns=cpu_warning, runtime_cell_stdout=stdout.get("7984f79d", "")[-400:])

    # ---- P09 DQA-m4: experiment subsets reported with their size/coverage and a reading note
    exp_cells = ["aada1835", "b1a10dd3", "6206457c"]
    coverage = {c: ("pages" in stdout.get(c, "")) for c in exp_cells}
    notes = {}
    for c in exp_cells:
        i = order.index(c)
        nxt_md = cells[i + 1][2] if i + 1 < len(cells) and cells[i + 1][1] == "markdown" else ""
        notes[c] = "What to notice" in nxt_md
    probe("P09", "DQA-m4", "clear" if all(coverage.values()) and all(notes.values()) else "open",
          coverage_printed=coverage, what_to_notice_after=notes, subset=default["experiment_subset"],
          outputs={c: stdout.get(c, "")[-500:] for c in exp_cells})

    # ---- P10 DQA-m5: terminology, metric explanation, glossary
    summary_out = stdout.get("8ad583a7", "")
    gloss = next((src for cid, kind, src in cells if kind == "markdown" and src.lstrip().startswith("# Glossary")), "")
    missing_terms = [t for t in ("OCR", "Exact Match", "Span", "window", "Patch", "Uncalibrated") if t.lower() not in gloss.lower()]
    metric_md = md.get("f3f4db23", "")
    anls_explained = ("edit" in metric_md.lower() or "levenshtein" in metric_md.lower())
    workshop_in_output = "Workshop" in summary_out
    probe("P10", "DQA-m5", "open" if (workshop_in_output or missing_terms or not anls_explained) else "clear",
          summary_first_line=summary_out.splitlines()[0] if summary_out else None,
          glossary_missing_terms=missing_terms, anls_computation_explained_in_section_9=anls_explained)

    results["open"] = [p["id"] + " " + p["finding"] for p in results["probes"] if p["status"] == "open"]
    out_path.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    print("open:", results["open"])


if __name__ == "__main__":
    main()
