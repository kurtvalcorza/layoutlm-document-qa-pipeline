"""Review probes for the receipt intelligence capstone (Notebook Review Framework v1).

Reviewed revision: kurtvalcorza/layoutlm-document-qa-pipeline @ ad47ef84d417cbb070c98b95bd6eb82bc4d7b7fd
Notebook: tutorials/DIMER_Small_Business_Receipt_Intelligence_Capstone.ipynb (blob 329fbfe87258...)

Usage (from a `git archive` export of that revision, CPU only, Python >= 3.11, stdlib only):

    python run_probes.py --src <export dir> --evidence <export dir>/docs/execution-evidence/2026-09-29

Writes results.json and source_manifest.json next to this file. P2 needs network access to
api.github.com; every other probe is offline. Nothing here edits the repository.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import math
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
NB_REL = "tutorials/DIMER_Small_Business_Receipt_Intelligence_Capstone.ipynb"
REPO = "kurtvalcorza/layoutlm-document-qa-pipeline"
BADGE_BRANCH = "feat/small-business-receipt-capstone"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cell_source(nb: dict, cell_id: str) -> str:
    return "".join(next(c for c in nb["cells"] if c.get("id") == cell_id)["source"])


def carried(nb: dict) -> tuple[dict, dict]:
    tree = ast.parse(cell_source(nb, "code-05"))
    out = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") in ("CARRIED_FILES", "CARRIED_HASHES"):
            out[node.targets[0].id] = ast.literal_eval(node.value)
    return out["CARRIED_FILES"], out["CARRIED_HASHES"]


def p1_carrier(nb: dict, src: Path) -> dict:
    files, hashes = carried(nb)
    meta = nb["metadata"]["dimer"]["generated_from"]["files"]
    rows = {}
    for name, text in files.items():
        h = hashlib.sha256(text.encode("utf-8")).hexdigest()
        tool = src / "tools" / ("receipt_capstone.py" if name == "capstone.py" else name)
        same_as_tool = None
        if name.endswith(".py") and tool.exists():
            same_as_tool = tool.read_text(encoding="utf-8").replace("\r\n", "\n") == text
        rows[name] = {"hash_ok": h == hashes[name], "metadata_ok": meta.get(name, h) == h, "equals_tools_source": same_as_tool}
    passed = all(r["hash_ok"] and r["metadata_ok"] and r["equals_tools_source"] in (None, True) for r in rows.values())
    return {"passed": passed, "files": len(rows), "detail": rows}


def p2_badge(nb: dict) -> dict:
    opening = "".join(nb["cells"][0]["source"])
    target = f"/blob/{BADGE_BRANCH}/"
    url = f"https://api.github.com/repos/{REPO}/branches/{BADGE_BRANCH.replace('/', '%2F')}"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "review-probe"}), timeout=30) as r:
            status = r.status
    except urllib.error.HTTPError as exc:
        status = exc.code
    except OSError as exc:  # offline
        status = f"not checked: {exc}"
    return {
        "badge_points_at_branch": target in opening,
        "branch_api_status": status,
        "finding_reproduced": target in opening and status == 404,
        "manual_observation_2026_10_02": (
            "Signed-out Colab at the badge URL showed the dialog 'There was an error loading this notebook. "
            "Ensure that the file is accessible and try again.' with 0 cells. The same notebook at "
            "/blob/main/ loaded 42 cells; control: the repo's workshop notebook loaded 68 cells."
        ),
    }


def p3_panel_labels(evidence: Path, src_carried: dict) -> dict:
    source = src_carried["capstone.py"]
    rule_present = 'if status in ("ambiguous", "unsupported", "parse_failed")' in source and '"numeric_ambiguity"' in source
    order_ok = source.index('"numeric_ambiguity"') < source.index('"extraction_error"\n                if rec')
    nb = json.loads((evidence / "receipt_capstone_7bd7f87_colab-t4.ipynb").read_text(encoding="utf-8"))
    text = ""
    for c in nb["cells"]:
        if c.get("id") == "code-30":
            for o in c.get("outputs", []):
                if "data" in o:
                    text += "".join(o["data"].get("text/markdown", []))
    row = next((ln for ln in text.splitlines() if ln.startswith("| numeric_ambiguity")), None)
    cells = [x.strip() for x in row.strip("|").split("|")] if row else []
    mislabelled = bool(cells) and cells[5] == "parse_failed" and cells[6] == "not_recoverable"
    return {
        "parse_failed_routed_to_numeric_ambiguity_before_recoverability": rule_present and order_ok,
        "colab_7bd7f87_numeric_ambiguity_row": cells,
        "finding_reproduced": rule_present and order_ok and mislabelled,
    }


def p4_policy_bound(src_dir: Path) -> dict:
    sys.path.insert(0, str(src_dir))
    import receipt_policy as policy  # carried, stdlib only

    def build(n_usable: int, n_correct: int):
        refs, preds, ids = {}, {}, []
        for i in range(n_usable):
            rid = f"r{i:02d}"
            ids.append(rid)
            refs[rid] = {"fields": {"total_amount": {"state": "present_usable", "normalized_amount": "1000"}}}
            ok = i < n_correct  # perfect ranking: every correct total outranks every wrong one
            preds[rid] = {"fields": {"total_amount": {
                "parse_status": "ok", "normalized_amount": "1000" if ok else "2000",
                "span_score": 1.0 - i / 1000, "raw_text": "x",
            }}}
        return preds, refs, ids

    grid = {}
    for n_correct in (15, 19, 20, 23, 25, 30):
        preds, refs, ids = build(49, n_correct)
        grid[str(n_correct)] = {}
        for target in (0.95, 0.90, 0.80, 0.75, 0.70):
            sel = policy.select(preds, refs, ids, "probe", {**policy.DEFAULT_TARGETS, "min_accuracy": target})
            grid[str(n_correct)][f"{target:.2f}"] = sel["policy"]["policy_feasible"]
    bound = {f"{t:.2f}": math.ceil(policy.DEFAULT_TARGETS["min_accepted"] * t) for t in (0.95, 0.90, 0.80, 0.75, 0.70)}
    return {
        "defaults": policy.DEFAULT_TARGETS,
        "feasible_with_perfect_ranking_49_usable": grid,
        "min_correct_totals_needed": bound,
        "documented_validation_model_total_correct_of_49": {"rules_baseline": 15, "layoutlm_frozen": 19, "layoutlm_adapted": 20},
        "finding_reproduced": not grid["20"]["0.95"] and not grid["20"]["0.90"] and grid["20"]["0.80"],
    }


def p5_bool_rendering(nb: dict) -> dict:
    src = cell_source(nb, "code-06")
    fmt_src = src[src.index("def _fmt"):src.index("def show_table")]
    ns: dict = {}
    exec(fmt_src, ns)
    shown = {repr(v): ns["_fmt"](v) for v in (True, False, None, 0.5, 7)}
    return {"rendered": shown, "finding_reproduced": shown["True"] == "1.0000" and shown["False"] == "0.0000"}


def p6_stale_text(nb: dict) -> dict:
    md = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
    probes = {
        "header_hosted_pending": "hosted qualification pending" in md,
        "no_time_promised_before_measured": "No elapsed time is promised before a qualified hosted run has measured it" in md,
        "ocr_install_open_item": "this is an open qualification item" in md,
        "feasibility_worked_answer": "a 90% target may make a policy feasible" in md,
        "rerun_instruction_for_section1_controls": any(
            s in md for s in ("re-run the §1", "rerun the §1", "run the §1 cell", "re-run the controls", "rerun the controls")
        ),
    }
    return {"present": probes}


def p7_byod_refusal(src_dir: Path, nb: dict) -> dict:
    sys.path.insert(0, str(src_dir))
    try:
        import receipt_artifact as artifact
    except ImportError as exc:  # needs safetensors/numpy; not stdlib
        return {"skipped": f"receipt_artifact import failed on this host: {exc}"}
    with tempfile.TemporaryDirectory() as tmp:
        z = Path(tmp) / "bad.zip"
        with zipfile.ZipFile(z, "w") as archive:
            archive.writestr("../escape.png", b"x")
        try:
            artifact.safe_extract(z, Path(tmp) / "out")
            refused = None
        except Exception as exc:  # noqa: BLE001 - recording the message is the probe
            refused = f"{type(exc).__name__}: {exc}"
    cell = cell_source(nb, "code-40")
    return {"refusal_message": refused, "cell40_uses_last_stderr_line": "inspect.stderr.strip().splitlines()[-1]" in cell}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--src", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    nb_path = args.src / NB_REL
    nb = json.loads(nb_path.read_text(encoding="utf-8"))
    files, _ = carried(nb)
    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        for name, text in files.items():
            (tmp_dir / name).parent.mkdir(parents=True, exist_ok=True)
            (tmp_dir / name).write_text(text, encoding="utf-8", newline="\n")
        results = {
            "revision": "ad47ef84d417cbb070c98b95bd6eb82bc4d7b7fd",
            "notebook_sha256": sha(nb_path),
            "P1_carrier_integrity": p1_carrier(nb, args.src),
            "P2_colab_badge": p2_badge(nb),
            "P3_failure_panel_labels": p3_panel_labels(args.evidence, files),
            "P4_review_policy_feasibility": p4_policy_bound(tmp_dir),
            "P5_show_json_boolean_rendering": p5_bool_rendering(nb),
            "P6_learner_text": p6_stale_text(nb),
            "P7_byod_refusal": p7_byod_refusal(tmp_dir, nb),
        }
    (HERE / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    inspected = [NB_REL, "tools/build_receipt_capstone.py", "docs/receipt-release-evidence.md",
                 "docs/receipt-capstone.md", "docs/receipt-capstone-spec.md", "docs/release-verification.md",
                 "tutorials/README.md"]
    inspected += [f"tools/{n}" for n in ("receipt_capstone.py", "receipt_policy.py", "receipt_fields.py",
                                          "receipt_byod.py", "receipt_artifact.py", "receipt_ocr.py")]
    inspected += [str(p.relative_to(args.src)).replace("\\", "/") for p in sorted(args.evidence.glob("receipt_capstone_7bd7f87_*"))]
    manifest = {rel: sha(args.src / rel) for rel in inspected if (args.src / rel).exists()}
    (HERE / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({k: (v.get("finding_reproduced", v) if isinstance(v, dict) else v) for k, v in results.items()}, indent=2))


if __name__ == "__main__":
    main()
